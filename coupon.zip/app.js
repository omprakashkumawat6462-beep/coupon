// GrabDeals Main Application Orchestration
import { CATEGORIES, STORES, getCoupons, DEALS_OF_THE_DAY, COLLECTIONS } from "./modules/coupons.js";
import { getBookmarks, getSubmissions } from "./modules/storage.js";
import { 
  renderCoupons, 
  renderStoreSelectors, 
  openCopyModal, 
  setupSavingsCalculator, 
  setupSearchAutosuggest, 
  setupSubmitDrawer,
  showNotification,
  renderDealsOfTheDay,
  renderCollections,
  setupHeaderAuthProfile,
  renderPopularOffers
} from "./modules/ui.js";

// Global App State
let activeStore = null;
let activeCategory = "all";
let activeType = "all"; // 'all', 'codes', 'deals', 'bookmarks'
let searchQuery = "";
let sliderIntervalId = null;

// DOM Elements cache
const couponsGrid = document.getElementById("coupons-grid-container");
const categoriesContainer = document.getElementById("categories-tabs-container");
const storesContainer = document.getElementById("stores-list-container");
const filterTitle = document.getElementById("current-filter-title");
const bookmarkBadge = document.getElementById("bookmark-badge");
const themeToggle = document.getElementById("theme-toggle-btn");
const themeIcon = document.getElementById("theme-icon");
const bookmarksToggle = document.getElementById("bookmarks-btn");
const newsletterForm = document.getElementById("newsletter-form");

document.addEventListener("DOMContentLoaded", () => {
  initApp();
});

function initApp() {
  // 1. Setup Theme
  setupTheme();

  // 2. Render Categories Selector tabs dynamically
  renderCategoriesTabs();

  // 3. Render Stores Selector grid
  renderStoreSelectors(storesContainer, handleSelectStore, activeStore);

  // 4. Render Deals Of The Day
  const dealsContainer = document.getElementById("deals-of-the-day-container");
  renderDealsOfTheDay(DEALS_OF_THE_DAY, dealsContainer);
  setupDealsTimer();

  // Render Popular Offers Of The Day
  const popularContainer = document.getElementById("popular-offers-container");
  if (popularContainer) {
    const popularCoupons = getCoupons().filter(c => c.popular === true);
    renderPopularOffers(popularCoupons, popularContainer, (coupon) => {
      openCopyModal(coupon);
    });
    setupPopularOffersSlider();
  }

  // 5. Render Collections
  const collectionsContainer = document.getElementById("collections-container");
  renderCollections(COLLECTIONS, collectionsContainer, handleSelectCollection);

  // 6. Setup Savings Calculator
  setupSavingsCalculator();

  // 7. Setup Submit Drawer
  setupSubmitDrawer(handleNewCouponSubmitted);

  // 8. Setup Search Autocomplete suggestions
  setupSearchAutosuggest(handleSelectStore, handleSelectCategory);

  // 9. Setup Carousel Slider
  setupCarousel();

  // 10. Bind Toolbar Action Buttons
  setupToolbarEvents();

  // 11. Update Bookmarks Counter Badge
  updateBookmarksBadge();
  document.addEventListener("bookmarks-changed", updateBookmarksBadge);

  // 12. Bind Footer Deep Links
  setupFooterLinks();

  // 13. Bind Newsletter Submit
  if (newsletterForm) {
    newsletterForm.addEventListener("submit", (e) => {
      e.preventDefault();
      const email = newsletterForm.querySelector("input").value;
      showNotification(`Subscribed successfully with: ${email}! 📧`);
      newsletterForm.reset();
    });
  }

  // 14. Render Initial Coupons Feed
  updateCouponFeed();

  // 15. Setup Header Auth Profile
  setupHeaderAuthProfile();
}

// -------------------------------------------------------------
// FILTER CONTROLLERS & DATA UPDATE
// -------------------------------------------------------------

function updateCouponFeed() {
  const baseCoupons = getCoupons();
  const customCoupons = getSubmissions();
  
  // Combine native data and user submissions
  let allCoupons = [...customCoupons, ...baseCoupons];

  // Apply Store Filter
  if (activeStore) {
    allCoupons = allCoupons.filter(c => c.store.toLowerCase() === activeStore.toLowerCase());
  }

  // Apply Category Filter
  if (activeCategory !== "all") {
    allCoupons = allCoupons.filter(c => c.category === activeCategory);
  }

  // Apply Coupon Type Filter (Promo Code vs Deal vs Bookmarked)
  if (activeType === "codes") {
    allCoupons = allCoupons.filter(c => !c.isDeal);
  } else if (activeType === "deals") {
    allCoupons = allCoupons.filter(c => c.isDeal);
  } else if (activeType === "bookmarks") {
    const bookmarkedIds = getBookmarks();
    allCoupons = allCoupons.filter(c => bookmarkedIds.includes(c.id));
  }

  // Apply Search Query Filter
  if (searchQuery) {
    allCoupons = allCoupons.filter(c => 
      c.store.toLowerCase().includes(searchQuery) ||
      c.title.toLowerCase().includes(searchQuery) ||
      c.description.toLowerCase().includes(searchQuery) ||
      c.discount.toLowerCase().includes(searchQuery)
    );
  }

  // Render Output
  renderCoupons(allCoupons, couponsGrid, handleCouponAction);

  // Update Status Text
  updateFilterTitleText(allCoupons.length);
}

function updateFilterTitleText(count) {
  let titleStr = `Showing ${count} active offer${count !== 1 ? 's' : ''}`;
  
  const filters = [];
  if (activeStore) filters.push(`for ${activeStore}`);
  if (activeCategory !== "all") {
    const catObj = CATEGORIES.find(cat => cat.id === activeCategory);
    if (catObj) filters.push(`in ${catObj.name}`);
  }
  if (activeType !== "all") {
    if (activeType === "codes") filters.push("(Promo Codes only)");
    if (activeType === "deals") filters.push("(Deals only)");
    if (activeType === "bookmarks") filters.push("(Bookmarked offers)");
  }
  if (searchQuery) filters.push(`matching "${searchQuery}"`);

  if (filters.length > 0) {
    titleStr += ` ${filters.join(" ")}`;
  } else {
    titleStr += ` overall`;
  }
  
  filterTitle.innerText = titleStr;
}

// -------------------------------------------------------------
// EVENT HANDLERS
// -------------------------------------------------------------

function handleSelectStore(storeName) {
  activeStore = storeName;
  
  // Re-render Store grid list to update active card selector UI state
  renderStoreSelectors(storesContainer, handleSelectStore, activeStore);
  
  // Clear search bar query when explicitly switching stores
  if (storeName) {
    const searchInput = document.getElementById("search-input");
    if (searchInput) searchInput.value = "";
    searchQuery = "";
  }

  updateCouponFeed();
}

function handleSelectCategory(categoryId) {
  activeCategory = categoryId;
  
  // Update categories tabs active CSS state
  const tabs = categoriesContainer.querySelectorAll(".filter-tab");
  tabs.forEach(tab => {
    const isMatched = tab.getAttribute("data-cat") === categoryId;
    tab.classList.toggle("active", isMatched);
  });

  updateCouponFeed();
}

function handleCouponAction(coupon) {
  openCopyModal(coupon);
}

function handleNewCouponSubmitted() {
  // Re-render the feed to include newly created coupon
  updateCouponFeed();
}

// -------------------------------------------------------------
// RENDERERS & INITIALIZATIONS
// -------------------------------------------------------------

function renderCategoriesTabs() {
  if (!categoriesContainer) return;
  categoriesContainer.innerHTML = "";

  CATEGORIES.forEach((cat) => {
    const btn = document.createElement("button");
    btn.className = `filter-tab ${activeCategory === cat.id ? "active" : ""}`;
    btn.setAttribute("data-cat", cat.id);
    btn.innerHTML = `<span>${cat.icon}</span> ${cat.name}`;
    btn.addEventListener("click", () => {
      if (cat.id === "all") {
        handleSelectCategory(cat.id);
      } else {
        window.location.href = `category.html?cat=${cat.id}`;
      }
    });
    categoriesContainer.appendChild(btn);
  });
}

// Setup Event Listeners
function setupToolbarEvents() {
  const typeAll = document.getElementById("type-all");
  const typeCodes = document.getElementById("type-codes");
  const typeDeals = document.getElementById("type-deals");
  const typeBookmarks = document.getElementById("type-bookmarks");
  const searchInput = document.getElementById("search-input");

  const types = [
    { btn: typeAll, val: "all" },
    { btn: typeCodes, val: "codes" },
    { btn: typeDeals, val: "deals" },
    { btn: typeBookmarks, val: "bookmarks" }
  ];

  types.forEach((item) => {
    if (!item.btn) return;
    item.btn.addEventListener("click", () => {
      // Toggle active states on buttons
      types.forEach(t => t.btn.classList.remove("active"));
      item.btn.classList.add("active");
      
      activeType = item.val;
      updateCouponFeed();
    });
  });

  // Track search bar direct typing (with 300ms debounce)
  let searchDebounceId = null;
  if (searchInput) {
    searchInput.addEventListener("keyup", (e) => {
      clearTimeout(searchDebounceId);
      searchDebounceId = setTimeout(() => {
        searchQuery = e.target.value.trim().toLowerCase();
        updateCouponFeed();
      }, 250);
    });
  }

  // Header bookmark button click: switch to Bookmarks tab & scroll
  if (bookmarksToggle) {
    bookmarksToggle.addEventListener("click", () => {
      types.forEach(t => t.btn.classList.remove("active"));
      if (typeBookmarks) typeBookmarks.classList.add("active");
      activeType = "bookmarks";
      
      updateCouponFeed();

      // Scroll to coupons feed
      const toolbarOffset = document.querySelector(".coupons-toolbar").offsetTop;
      window.scrollTo({
        top: toolbarOffset - 100,
        behavior: "smooth"
      });
    });
  }
}

function updateBookmarksBadge() {
  if (!bookmarkBadge) return;
  const count = getBookmarks().length;
  bookmarkBadge.innerText = count;
  bookmarkBadge.style.display = count > 0 ? "flex" : "none";
}

function setupTheme() {
  if (!themeToggle || !themeIcon) return;

  const currentTheme = localStorage.getItem("grabdeals_theme") || "dark";
  if (currentTheme === "light") {
    document.body.classList.add("light-theme");
    themeIcon.innerHTML = '<i class="fa-solid fa-sun"></i>';
  } else {
    document.body.classList.remove("light-theme");
    themeIcon.innerHTML = '<i class="fa-solid fa-moon"></i>';
  }

  themeToggle.addEventListener("click", () => {
    const isLight = document.body.classList.toggle("light-theme");
    themeIcon.innerHTML = isLight ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
    localStorage.setItem("grabdeals_theme", isLight ? "light" : "dark");
  });
}

function setupCarousel() {
  const heroSlider = document.getElementById("hero-slider");
  const dotsContainer = document.getElementById("slider-dots-container");
  
  if (!heroSlider || !dotsContainer) return;

  const slides = heroSlider.querySelectorAll(".slide");
  const dots = dotsContainer.querySelectorAll(".dot");
  let currentSlideIndex = 0;

  function goToSlide(index) {
    slides[currentSlideIndex].classList.remove("active");
    dots[currentSlideIndex].classList.remove("active");

    currentSlideIndex = index;

    slides[currentSlideIndex].classList.add("active");
    dots[currentSlideIndex].classList.add("active");
  }

  function nextSlide() {
    let nextIndex = currentSlideIndex + 1;
    if (nextIndex >= slides.length) nextIndex = 0;
    goToSlide(nextIndex);
  }

  // Dots click events
  dots.forEach((dot) => {
    dot.addEventListener("click", () => {
      const idx = parseInt(dot.getAttribute("data-index"));
      goToSlide(idx);
      resetSliderTimer();
    });
  });

  // Carousel CTA click: scroll and filter to that store
  heroSlider.querySelectorAll(".slide-cta").forEach((cta) => {
    cta.addEventListener("click", (e) => {
      const storeName = e.target.getAttribute("data-store");
      handleSelectStore(storeName);
      
      // Scroll to coupons feed
      const toolbarOffset = document.querySelector(".coupons-toolbar").offsetTop;
      window.scrollTo({
        top: toolbarOffset - 100,
        behavior: "smooth"
      });
    });
  });

  // Start Interval Timer
  function startSliderTimer() {
    sliderIntervalId = setInterval(nextSlide, 5000);
  }

  function resetSliderTimer() {
    clearInterval(sliderIntervalId);
    startSliderTimer();
  }

  // Auto-pause timer on hover to make reading banners easier
  heroSlider.addEventListener("mouseenter", () => clearInterval(sliderIntervalId));
  heroSlider.addEventListener("mouseleave", startSliderTimer);

  startSliderTimer();
}

function setupFooterLinks() {
  // Hook store links in footer
  document.querySelectorAll(".foot-store-link").forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const store = link.getAttribute("data-store");
      handleSelectStore(store);
      scrollToCouponsGrid();
    });
  });

  // Hook category links in footer
  document.querySelectorAll(".foot-cat-link").forEach((link) => {
    link.addEventListener("click", (e) => {
      e.preventDefault();
      const catId = link.getAttribute("data-cat");
      handleSelectCategory(catId);
      scrollToCouponsGrid();
    });
  });
}

function scrollToCouponsGrid() {
  const grid = document.getElementById("coupons-grid-container");
  if (!grid) return;
  const offset = grid.offsetTop - 180;
  window.scrollTo({
    top: offset,
    behavior: "smooth"
  });
}

// Countdown Timer for Deals Of The Day
function setupDealsTimer() {
  const timerElement = document.getElementById("deals-timer");
  if (!timerElement) return;

  function updateTimer() {
    const now = new Date();
    // Calculate time until midnight
    const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
    const diff = midnight - now;

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    const pad = (num) => String(num).padStart(2, "0");
    timerElement.innerText = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  }

  setInterval(updateTimer, 1000);
  updateTimer(); // Initial call
}

// Click Handler for Collections
function handleSelectCollection(col) {
  // Set filters based on collection selection
  activeStore = col.filterStore;
  activeCategory = col.filterCat || "all";
  activeType = "all";

  // Reset active button states in coupon types
  const typeAllBtn = document.getElementById("type-all");
  if (typeAllBtn) {
    const types = [
      typeAllBtn,
      document.getElementById("type-codes"),
      document.getElementById("type-deals"),
      document.getElementById("type-bookmarks")
    ];
    types.forEach(t => t && t.classList.remove("active"));
    typeAllBtn.classList.add("active");
  }

  // Re-render Store grid list to update active card selector UI state
  renderStoreSelectors(storesContainer, handleSelectStore, activeStore);

  // Update Category tabs styling
  const tabs = categoriesContainer.querySelectorAll(".filter-tab");
  tabs.forEach(tab => {
    const isMatched = tab.getAttribute("data-cat") === activeCategory;
    tab.classList.toggle("active", isMatched);
  });

  // Re-render coupons feed
  updateCouponFeed();

  // Scroll smoothly to coupons feed
  const toolbar = document.querySelector(".coupons-toolbar");
  if (toolbar) {
    window.scrollTo({
      top: toolbar.offsetTop - 100,
      behavior: "smooth"
    });
  }

  showNotification(`Showing Collection: ${col.title}! 🎯`);
}

// Popular Offers Horizontal Slider Logic
function setupPopularOffersSlider() {
  const track = document.getElementById("popular-offers-container");
  const prevBtn = document.getElementById("popular-prev-btn");
  const nextBtn = document.getElementById("popular-next-btn");
  if (!track || !prevBtn || !nextBtn) return;

  let currentIndex = 0;

  const getVisibleCardsCount = () => {
    if (window.innerWidth <= 600) return 1;
    if (window.innerWidth <= 1024) return 2;
    return 4;
  };

  const updateSliderPosition = () => {
    const card = track.querySelector(".popular-slider-card");
    if (!card) return;
    
    const cardWidth = card.getBoundingClientRect().width;
    const gap = 24;
    const slideAmount = (cardWidth + gap) * currentIndex;
    track.style.transform = `translateX(-${slideAmount}px)`;
  };

  nextBtn.addEventListener("click", () => {
    const totalCards = track.querySelectorAll(".popular-slider-card").length;
    const visibleCards = getVisibleCardsCount();
    const maxIndex = totalCards - visibleCards;

    if (currentIndex < maxIndex) {
      currentIndex++;
      updateSliderPosition();
    }
  });

  prevBtn.addEventListener("click", () => {
    if (currentIndex > 0) {
      currentIndex--;
      updateSliderPosition();
    }
  });

  // Handle Resize
  window.addEventListener("resize", () => {
    currentIndex = 0;
    track.style.transform = "translateX(0)";
  });
}
