Place image assets (.png, .jpg, .svg) for GrabDeals in this folder.
