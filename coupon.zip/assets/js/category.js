// GrabDeals Category Page Controller
import { CATEGORIES, STORES, getCoupons } from "./modules/coupons.js";
import { getBookmarks } from "./modules/storage.js";
import { 
  renderCoupons, 
  openCopyModal, 
  setupSearchAutosuggest, 
  setupSubmitDrawer,
  showNotification,
  setupHeaderAuthProfile
} from "./modules/ui.js";

// DOM Cache
const catHeroIcon = document.getElementById("cat-hero-icon");
const catHeroTitle = document.getElementById("cat-hero-title");
const catHeroDesc = document.getElementById("cat-hero-desc");
const topStoresContainer = document.getElementById("top-stores-container");
const otherCategoriesContainer = document.getElementById("other-categories-container");
const couponsGrid = document.getElementById("coupons-grid-container");
const categoryGuideContainer = document.getElementById("category-guide-container");
const bookmarkBadge = document.getElementById("bookmark-badge");
const themeToggle = document.getElementById("theme-toggle-btn");
const themeIcon = document.getElementById("theme-icon");

// State
let currentCategoryKey = "food";
let currentCategoryMeta = null;

document.addEventListener("DOMContentLoaded", () => {
  initCategoryPage();
});

function initCategoryPage() {
  // 1. Parse URL Parameter
  const params = new URLSearchParams(window.location.search);
  const catParam = params.get("cat");

  // Match category key case-insensitively or default to food
  const matchedKey = Object.keys(CATEGORIES).find(
    k => k.toLowerCase() === (catParam || "").toLowerCase()
  );

  currentCategoryKey = matchedKey || "food";
  currentCategoryMeta = CATEGORIES[currentCategoryKey];

  // Update Page Title
  document.title = `${currentCategoryMeta.name} Coupons & Promo Codes - GrabDeals`;

  // 2. Setup Theme
  setupTheme();

  // 3. Render Hero Section
  renderHero();

  // 4. Render Top Stores for this Category
  renderTopStores();

  // 5. Render Other Categories List
  renderOtherCategories();

  // 6. Render Coupons
  renderCategoryCoupons();

  // 7. Render Saving Guide
  renderCategoryGuide();

  // 8. Bind Submit Drawer
  setupSubmitDrawer(() => {
    showNotification("Coupon submitted successfully for moderation! 🚀");
  });

  // 9. Setup Search Autosuggestion
  setupSearchAutosuggest(
    (store) => { window.location.href = `store.html?store=${store}`; },
    (cat) => { window.location.href = `category.html?cat=${cat}`; }
  );

  // 10. Bookmarks Badge Updates
  updateBookmarksBadge();
  document.addEventListener("bookmarks-changed", updateBookmarksBadge);

  // 11. Setup Header Auth Profile
  setupHeaderAuthProfile();
}

// Render Hero header details
function renderHero() {
  catHeroIcon.innerText = currentCategoryMeta.icon;
  catHeroTitle.innerText = `${currentCategoryMeta.name} Coupons & Promo Codes`;
  catHeroDesc.innerText = `Find the best verified offers, free delivery deals, and promo voucher codes for ${currentCategoryMeta.name.toLowerCase()} brands.`;
}

// Render Top Stores for this Category in the Sidebar
function renderTopStores() {
  topStoresContainer.innerHTML = "";
  const allCoupons = getCoupons();

  // Filter coupons belonging to this category
  const catCoupons = allCoupons.filter(
    c => c.category.toLowerCase() === currentCategoryKey.toLowerCase()
  );

  // Extract unique stores that have active coupons in this category
  const storeNames = [...new Set(catCoupons.map(c => c.store))];

  if (storeNames.length === 0) {
    topStoresContainer.innerHTML = `<p style="color: var(--text-muted); font-size: 0.85rem;">No stores active in this category.</p>`;
    return;
  }

  // Display top stores
  storeNames.slice(0, 5).forEach(name => {
    const store = STORES[name];
    if (!store) return;

    const link = document.createElement("a");
    link.href = `store.html?store=${name}`;
    link.className = "top-store-item";
    
    const logoUrl = store.domain ? `https://logos.hunter.io/${store.domain}` : "";

    link.innerHTML = `
      <div class="top-store-logo" style="background: ${store.color}">
        ${logoUrl 
          ? `<img src="${logoUrl}" alt="${store.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">`
          : ""
        }
        <span style="${logoUrl ? 'display: none;' : 'font-size: 0.85rem;'}">${store.icon}</span>
      </div>
      <span>${store.name}</span>
    `;
    topStoresContainer.appendChild(link);
  });
}

// Render Other Categories List in Sidebar
function renderOtherCategories() {
  otherCategoriesContainer.innerHTML = "";

  Object.keys(CATEGORIES).forEach(k => {
    if (k === currentCategoryKey) return; // skip active

    const cat = CATEGORIES[k];
    const link = document.createElement("a");
    link.href = `category.html?cat=${k}`;
    link.className = "top-store-item";
    link.innerHTML = `
      <div class="top-store-logo" style="background: rgba(255, 255, 255, 0.05);">
        <span>${cat.icon}</span>
      </div>
      <span>${cat.name}</span>
    `;
    otherCategoriesContainer.appendChild(link);
  });
}

// Render Category Coupons Feed
function renderCategoryCoupons() {
  const allCoupons = getCoupons();
  const catCoupons = allCoupons.filter(
    c => c.category.toLowerCase() === currentCategoryKey.toLowerCase()
  );

  if (catCoupons.length === 0) {
    couponsGrid.innerHTML = `
      <div class="no-results-card">
        <p style="font-size: 1.1rem; font-weight: 600;">No active coupons for this category today!</p>
        <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 5px;">Explore other popular stores in the side panel.</p>
      </div>
    `;
    return;
  }

  renderCoupons(catCoupons, couponsGrid, (coupon) => {
    openCopyModal(coupon);
  });
}

// Render Bottom Category Saving Guide
function renderCategoryGuide() {
  categoryGuideContainer.innerHTML = `
    <h3>Ultimate Savings Guide for ${currentCategoryMeta.name}</h3>
    <p>
      Whether you are ordering food, renewing your server hosting plan, or shopping for the latest fashion garments, GrabDeals verifies coupons daily to ensure you check out at the lowest prices. 
    </p>
    <p><strong>Follow these simple tips to secure maximum savings:</strong></p>
    <ul>
      <li><strong>Combine Offers:</strong> Keep an eye out for bank credit/debit card instant discounts which can often be stacked on top of store promo codes.</li>
      <li><strong>Newsletter Subscriptions:</strong> Sign up for store updates. Top brands frequently send 10-15% private welcome codes to email subscribers.</li>
      <li><strong>Check Expiry:</strong> All our coupons display an expiry date. Always grab deals with the "Verified" tick mark for guaranteed discounts.</li>
    </ul>
  `;
}

// Theme setup logic
function setupTheme() {
  const currentTheme = localStorage.getItem("theme") || "dark";
  document.documentElement.setAttribute("data-theme", currentTheme);
  updateThemeIcon(currentTheme);

  themeToggle.addEventListener("click", () => {
    const theme = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
    updateThemeIcon(theme);
  });
}

function updateThemeIcon(theme) {
  themeIcon.innerHTML = theme === "dark" ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
}

function updateBookmarksBadge() {
  const bookmarks = getBookmarks();
  bookmarkBadge.innerText = bookmarks.length;
}
