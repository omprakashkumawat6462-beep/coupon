// GrabDeals Authentication Page Controller
import { getBookmarks } from "./modules/storage.js";
import { 
  setupSearchAutosuggest, 
  setupSubmitDrawer,
  showNotification,
  setupHeaderAuthProfile
} from "./modules/ui.js";

// DOM Cache
const tabLoginBtn = document.getElementById("tab-login-btn");
const tabRegisterBtn = document.getElementById("tab-register-btn");
const loginForm = document.getElementById("login-form");
const registerForm = document.getElementById("register-form");

const loginEmail = document.getElementById("login-email");
const loginPassword = document.getElementById("login-password");
const loginPwdToggle = document.getElementById("login-pwd-toggle");

const regName = document.getElementById("reg-name");
const regEmail = document.getElementById("reg-email");
const regPassword = document.getElementById("reg-password");
const regPwdToggle = document.getElementById("reg-pwd-toggle");

const googleLoginBtn = document.getElementById("google-login-btn");
const fbLoginBtn = document.getElementById("fb-login-btn");
const googleRegBtn = document.getElementById("google-reg-btn");
const fbRegBtn = document.getElementById("fb-reg-btn");

const bookmarkBadge = document.getElementById("bookmark-badge");
const themeToggle = document.getElementById("theme-toggle-btn");
const themeIcon = document.getElementById("theme-icon");

document.addEventListener("DOMContentLoaded", () => {
  initLoginPage();
});

function initLoginPage() {
  // 1. Setup Theme
  setupTheme();

  // 2. Tab Switches Listener
  tabLoginBtn.addEventListener("click", () => switchTab("login"));
  tabRegisterBtn.addEventListener("click", () => switchTab("register"));

  // 3. Password Visibility Toggles
  setupPasswordToggle(loginPassword, loginPwdToggle);
  setupPasswordToggle(regPassword, regPwdToggle);

  // 4. Form Submit Handler
  loginForm.addEventListener("submit", handleLoginSubmit);
  registerForm.addEventListener("submit", handleRegisterSubmit);

  // 5. Social Mock Auths
  setupSocialMocks();

  // 6. Setup Drawer & Autosuggest
  setupSubmitDrawer(() => {
    showNotification("Coupon submitted successfully for moderation! 🚀");
  });

  setupSearchAutosuggest(
    (store) => { window.location.href = `store.html?store=${store}`; },
    (cat) => { window.location.href = `category.html?cat=${cat}`; }
  );

  // 7. Update Bookmarks Badge & Profile Header
  updateBookmarksBadge();
  setupHeaderAuthProfile();
}

function switchTab(mode) {
  if (mode === "login") {
    tabLoginBtn.classList.add("active");
    tabRegisterBtn.classList.remove("active");
    loginForm.classList.add("active");
    registerForm.classList.remove("active");
  } else {
    tabRegisterBtn.classList.add("active");
    tabLoginBtn.classList.remove("active");
    registerForm.classList.add("active");
    loginForm.classList.remove("active");
  }
}

function setupPasswordToggle(input, btn) {
  btn.addEventListener("click", (e) => {
    e.preventDefault();
    if (input.type === "password") {
      input.type = "text";
      btn.innerHTML = '<i class="fa-solid fa-eye-slash"></i>';
    } else {
      input.type = "password";
      btn.innerHTML = '<i class="fa-solid fa-eye"></i>';
    }
  });
}

function handleLoginSubmit(e) {
  e.preventDefault();
  const email = loginEmail.value;
  
  // Create mock display name from email
  let displayName = email.split("@")[0];
  displayName = displayName.charAt(0).toUpperCase() + displayName.slice(1);

  saveUserProfile({
    name: displayName,
    email: email,
    provider: "credentials"
  });

  showNotification(`Welcome back, ${displayName}! Logging in... 🔓`);

  setTimeout(() => {
    window.location.href = "index.html";
  }, 1500);
}

function handleRegisterSubmit(e) {
  e.preventDefault();
  const name = regName.value;
  const email = regEmail.value;

  saveUserProfile({
    name: name,
    email: email,
    provider: "credentials"
  });

  showNotification(`Account created successfully! Welcome, ${name.split(" ")[0]}! 🎉`);

  setTimeout(() => {
    window.location.href = "index.html";
  }, 1500);
}

function setupSocialMocks() {
  const triggerSocialAuth = (mockName) => {
    saveUserProfile({
      name: mockName,
      email: `${mockName.toLowerCase().replace(" ", "")}@auth.com`,
      provider: "social"
    });
    showNotification(`Logged in successfully with ${mockName}! 🌐`);
    setTimeout(() => {
      window.location.href = "index.html";
    }, 1500);
  };

  [googleLoginBtn, googleRegBtn].forEach(btn => {
    btn.addEventListener("click", () => triggerSocialAuth("Google Saver"));
  });

  [fbLoginBtn, fbRegBtn].forEach(btn => {
    btn.addEventListener("click", () => triggerSocialAuth("Social Shopper"));
  });
}

function saveUserProfile(profile) {
  localStorage.setItem("user_profile", JSON.stringify(profile));
}

function setupTheme() {
  const currentTheme = localStorage.getItem("theme") || "dark";
  document.documentElement.setAttribute("data-theme", currentTheme);
  updateThemeIcon(currentTheme);

  themeToggle.addEventListener("click", () => {
    const theme = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
    updateThemeIcon(theme);
  });
}

function updateThemeIcon(theme) {
  themeIcon.innerHTML = theme === "dark" ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
}

function updateBookmarksBadge() {
  const bookmarks = getBookmarks();
  bookmarkBadge.innerText = bookmarks.length;
}
