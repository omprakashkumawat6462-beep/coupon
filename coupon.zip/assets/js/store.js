// GrabDeals Store/Merchant Page Controller
import { STORES, getCoupons } from "./modules/coupons.js";
import { getBookmarks } from "./modules/storage.js";
import { 
  renderCoupons, 
  openCopyModal, 
  setupSearchAutosuggest, 
  setupSubmitDrawer,
  showNotification,
  setupHeaderAuthProfile
} from "./modules/ui.js";

// DOM Cache
const storeLogoWrapper = document.getElementById("store-logo-wrapper");
const storeTitle = document.getElementById("store-title");
const storeRatingVal = document.getElementById("store-rating-val");
const storeReviewsCount = document.getElementById("store-reviews-count");
const storeOffersCount = document.getElementById("store-offers-count");
const storeDesc = document.getElementById("store-desc");
const similarStoresContainer = document.getElementById("similar-stores-container");
const savingsTipsContainer = document.getElementById("savings-tips-container");
const couponsGrid = document.getElementById("coupons-grid-container");
const faqSection = document.getElementById("store-faq-section");
const faqAccordionContainer = document.getElementById("faq-accordion-container");
const bookmarkBadge = document.getElementById("bookmark-badge");
const themeToggle = document.getElementById("theme-toggle-btn");
const themeIcon = document.getElementById("theme-icon");

// State
let currentStoreKey = "";
let currentStoreMeta = null;

document.addEventListener("DOMContentLoaded", () => {
  initStorePage();
});

function initStorePage() {
  // 1. Parse URL Parameter
  const params = new URLSearchParams(window.location.search);
  const storeName = params.get("store");
  
  // Find key matching case-insensitively or default to Swiggy
  const matchedKey = Object.keys(STORES).find(
    k => k.toLowerCase() === (storeName || "").toLowerCase()
  );

  currentStoreKey = matchedKey || "Swiggy";
  currentStoreMeta = STORES[currentStoreKey];

  // Update Page Title
  document.title = `${currentStoreMeta.name} Coupons & Promo Codes - GrabDeals`;

  // 2. Setup Theme & Dark/Light Toggle
  setupTheme();

  // 3. Render Hero Header Card
  renderHeroBanner();

  // 4. Render Similar Stores Sidebar
  renderSimilarStores();

  // 5. Render Saving Tips List
  renderSavingTips();

  // 6. Render Store Coupons
  renderStoreCoupons();

  // 7. Render FAQ Accordion
  renderFaqAccordion();

  // 8. Bind Submit Drawer
  setupSubmitDrawer(() => {
    showNotification("Coupon submitted successfully for moderation! 🚀");
  });

  // 9. Setup Search Autosuggestion
  setupSearchAutosuggest(
    (store) => { window.location.href = `store.html?store=${store}`; },
    (cat) => { window.location.href = `category.html?cat=${cat}`; }
  );

  // 10. Bookmarks Badge Updates
  updateBookmarksBadge();
  document.addEventListener("bookmarks-changed", updateBookmarksBadge);

  // 11. Setup Header Auth Profile
  setupHeaderAuthProfile();
}

// Render Hero details
function renderHeroBanner() {
  const logoUrl = currentStoreMeta.domain ? `https://logos.hunter.io/${currentStoreMeta.domain}` : "";
  
  storeLogoWrapper.style.background = currentStoreMeta.color;
  storeLogoWrapper.innerHTML = logoUrl 
    ? `<img src="${logoUrl}" alt="${currentStoreMeta.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">`
    : "";
  storeLogoWrapper.innerHTML += `<span style="${logoUrl ? 'display: none;' : ''}">${currentStoreMeta.icon}</span>`;

  storeTitle.innerText = `${currentStoreMeta.name} Coupons & Promo Codes`;
  storeRatingVal.innerText = currentStoreMeta.rating;
  storeReviewsCount.innerText = `(${currentStoreMeta.reviews})`;
  storeDesc.innerText = currentStoreMeta.description;
}

// Render Similar Stores Widget
function renderSimilarStores() {
  similarStoresContainer.innerHTML = "";
  
  // Get up to 4 other stores
  const keys = Object.keys(STORES).filter(k => k !== currentStoreKey).slice(0, 4);
  
  keys.forEach(k => {
    const store = STORES[k];
    const link = document.createElement("a");
    link.href = `store.html?store=${k}`;
    link.className = "similar-store-item";
    
    const logoUrl = store.domain ? `https://logos.hunter.io/${store.domain}` : "";

    link.innerHTML = `
      <div class="similar-store-logo" style="background: ${store.color}">
        ${logoUrl 
          ? `<img src="${logoUrl}" alt="${store.name}" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">`
          : ""
        }
        <span style="${logoUrl ? 'display: none;' : 'font-size: 0.85rem;'}">${store.icon}</span>
      </div>
      <span>${store.name} Coupons</span>
    `;
    similarStoresContainer.appendChild(link);
  });
}

// Render Saving Tips Sidebar
function renderSavingTips() {
  savingsTipsContainer.innerHTML = "";
  if (!currentStoreMeta.savingTips || currentStoreMeta.savingTips.length === 0) {
    document.getElementById("tips-widget-title").style.display = "none";
    return;
  }
  
  currentStoreMeta.savingTips.forEach(tip => {
    const li = document.createElement("li");
    li.innerText = tip;
    savingsTipsContainer.appendChild(li);
  });
}

// Render Store specific coupons
function renderStoreCoupons() {
  const allCoupons = getCoupons();
  // Filter coupons belonging to this store
  const storeCoupons = allCoupons.filter(
    c => c.store.toLowerCase() === currentStoreMeta.name.toLowerCase()
  );

  storeOffersCount.innerText = storeCoupons.length;

  if (storeCoupons.length === 0) {
    couponsGrid.innerHTML = `
      <div class="no-results-card">
        <p style="font-size: 1.1rem; font-weight: 600;">No active coupons for ${currentStoreMeta.name} today!</p>
        <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 5px;">Check back later or browse other popular categories.</p>
      </div>
    `;
    return;
  }

  renderCoupons(storeCoupons, couponsGrid, (coupon) => {
    openCopyModal(coupon);
  });
}

// Render Accordion FAQ widgets
function renderFaqAccordion() {
  faqAccordionContainer.innerHTML = "";
  if (!currentStoreMeta.faqs || currentStoreMeta.faqs.length === 0) {
    faqSection.style.display = "none";
    return;
  }

  faqSection.style.display = "block";
  document.getElementById("faq-section-title").innerText = `${currentStoreMeta.name} Frequently Asked Questions`;

  currentStoreMeta.faqs.forEach(faq => {
    const item = document.createElement("div");
    item.className = "accordion-item";
    item.innerHTML = `
      <button class="accordion-header">
        <span>${faq.q}</span>
        <span class="accordion-icon"><i class="fa-solid fa-plus"></i></span>
      </button>
      <div class="accordion-content">
        <p style="padding-bottom: 8px;">${faq.a}</p>
      </div>
    `;

    // Click logic
    const btn = item.querySelector(".accordion-header");
    btn.addEventListener("click", () => {
      const isActive = item.classList.contains("active");
      
      // Close all first
      faqAccordionContainer.querySelectorAll(".accordion-item").forEach(el => {
        el.classList.remove("active");
        el.querySelector(".accordion-content").style.maxHeight = null;
      });

      if (!isActive) {
        item.classList.add("active");
        const panel = item.querySelector(".accordion-content");
        panel.style.maxHeight = panel.scrollHeight + "px";
      }
    });

    faqAccordionContainer.appendChild(item);
  });
}

// Theme setup logic
function setupTheme() {
  const currentTheme = localStorage.getItem("theme") || "dark";
  document.documentElement.setAttribute("data-theme", currentTheme);
  updateThemeIcon(currentTheme);

  themeToggle.addEventListener("click", () => {
    const theme = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
    updateThemeIcon(theme);
  });
}

function updateThemeIcon(theme) {
  themeIcon.innerHTML = theme === "dark" ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
}

function updateBookmarksBadge() {
  const bookmarks = getBookmarks();
  bookmarkBadge.innerText = bookmarks.length;
}
