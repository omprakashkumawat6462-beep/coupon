// GrabDeals Coupon Store
export const CATEGORIES = [
  { id: "all", name: "All Categories", icon: "🎟️" },
  { id: "food", name: "Food & Dining", icon: "🍔" },
  { id: "fashion", name: "Fashion & Apparel", icon: "👗" },
  { id: "electronics", name: "Electronics & Mobiles", icon: "⚡" },
  { id: "travel", name: "Travel & Flights", icon: "✈️" },
  { id: "hosting", name: "Hosting & Domains", icon: "🌐" }
];

export const STORES = {
  Swiggy: {
    name: "Swiggy",
    domain: "swiggy.com",
    color: "linear-gradient(135deg, #FF6B00 0%, #FF8A00 100%)",
    logoColor: "#FFFFFF",
    textColor: "#FF6B00",
    icon: "🍊",
    url: "https://www.swiggy.com",
    rating: "4.7",
    reviews: "12,850 Ratings",
    description: "Swiggy is India's leading on-demand food delivery platform, connecting consumers with thousands of restaurants, groceries via Instamart, and daily dining deals.",
    savingTips: [
      "Use WELCOME50 on your first food order to save flat 50% up to ₹100.",
      "Subscribe to Swiggy One to get free delivery on food orders and Instamart grocery orders.",
      "Look for restaurants running 'Free Delivery' and 'Match Day' discounts to save more."
    ],
    faqs: [
      {
        q: "How do I apply Swiggy coupons?",
        a: "Add food items to your cart, click on 'Apply Coupon' on the shopping bag page, type or select a coupon from GrabDeals, and click apply."
      },
      {
        q: "Can I get free delivery on Swiggy?",
        a: "Yes! You can get free delivery by subscribing to the Swiggy One membership or by ordering from restaurants running free delivery promotional deals."
      }
    ]
  },
  Amazon: {
    name: "Amazon",
    domain: "amazon.in",
    color: "linear-gradient(135deg, #111 0%, #232f3e 100%)",
    logoColor: "#FF9900",
    textColor: "#FF9900",
    icon: "🛒",
    url: "https://www.amazon.in",
    rating: "4.8",
    reviews: "45,900 Ratings",
    description: "Amazon India is the country's largest online shopping destination, offering massive discounts on electronics, laptops, home essentials, fashion, and pantry items.",
    savingTips: [
      "Get Amazon Prime for free fast delivery, early deal access, and Prime Video streaming.",
      "Apply for the Amazon Pay ICICI Bank Credit Card to earn 5% unlimited cashback.",
      "Shop during seasonal events like the Great Indian Festival for deep clearance discounts."
    ],
    faqs: [
      {
        q: "How do I use Amazon promo codes?",
        a: "At the checkout page under payment options, paste your promo code inside the 'Gift Cards & Promo Codes' input box and apply."
      },
      {
        q: "Is shipping free for Amazon purchases?",
        a: "Yes, shipping is completely free for all Amazon Prime members, and for non-Prime members on orders above ₹499."
      }
    ]
  },
  Flipkart: {
    name: "Flipkart",
    domain: "flipkart.com",
    color: "linear-gradient(135deg, #2874F0 0%, #1B4F93 100%)",
    logoColor: "#FFE500",
    textColor: "#2874F0",
    icon: "🛍️",
    url: "https://www.flipkart.com",
    rating: "4.6",
    reviews: "38,400 Ratings",
    description: "Flipkart is India's leading homegrown e-commerce portal, featuring incredible discounts on smart TVs, mobiles, clothing, furniture, and groceries.",
    savingTips: [
      "Accumulate Flipkart SuperCoins on every purchase to redeem gift cards and free rewards.",
      "Get the Flipkart Axis Bank Credit Card to enjoy 5% unlimited cashback.",
      "Avail of exchange offers to trade in old electronics for huge discounts on new purchases."
    ],
    faqs: [
      {
        q: "Where do I apply a Flipkart coupon?",
        a: "Flipkart deals are generally pre-applied. For coupon codes, you can enter the voucher code on the order confirmation checkout screen."
      },
      {
        q: "What is the Flipkart Plus program?",
        a: "Flipkart Plus is a free loyalty program where users earn double SuperCoins, get free fast shipping, and receive early access to mega sales."
      }
    ]
  },
  Myntra: {
    name: "Myntra",
    domain: "myntra.com",
    color: "linear-gradient(135deg, #E81A5F 0%, #FF5A36 100%)",
    logoColor: "#FFFFFF",
    textColor: "#E81A5F",
    icon: "👠",
    url: "https://www.myntra.com",
    rating: "4.7",
    reviews: "24,650 Ratings",
    description: "Myntra is India's ultimate destination for online fashion and lifestyle, offering top global apparel brands, shoes, makeup, and designer wear.",
    savingTips: [
      "New users get flat ₹300 Off + Free Shipping on their first shopping order.",
      "Join the Myntra Insider program to swap coins for exclusive brand discount coupons.",
      "Check out bank offers during End of Reason Sales for an extra 10% instant discount."
    ],
    faqs: [
      {
        q: "How do I redeem Myntra coupon codes?",
        a: "Open your shopping bag, click 'Apply Coupon' on the right sidebar, enter the code from GrabDeals, and click apply."
      },
      {
        q: "Can I get free delivery on Myntra?",
        a: "First-time shoppers get free shipping on their first order. For returning users, shipping is free on orders of ₹799 or more."
      }
    ]
  },
  Hostinger: {
    name: "Hostinger",
    domain: "hostinger.com",
    color: "linear-gradient(135deg, #673AB7 0%, #512DA8 100%)",
    logoColor: "#FFFFFF",
    textColor: "#673AB7",
    icon: "💻",
    url: "https://www.hostinger.in",
    rating: "4.9",
    reviews: "8,400 Ratings",
    description: "Hostinger provides affordable and high-speed web hosting services, including WordPress hosting, cloud servers, free domains, and free SSL.",
    savingTips: [
      "Purchase a 48-month subscription plan to lock in the absolute lowest monthly rate.",
      "Use our exclusive code GRABDEALS10 at checkout to save an extra 10% globally.",
      "Select a Business plan to get a free domain registration, free backup, and CDN."
    ],
    faqs: [
      {
        q: "Does Hostinger give a free domain name?",
        a: "Yes! Hostinger includes a free domain name (.com, .in, or .net) for the first year with Premium or higher hosting packages."
      },
      {
        q: "Is there a refund policy on Hostinger?",
        a: "Yes, Hostinger offers a 30-day money-back guarantee if you are not fully satisfied with their hosting services."
      }
    ]
  },
  Zomato: {
    name: "Zomato",
    domain: "zomato.com",
    color: "linear-gradient(135deg, #CB202D 0%, #B01824 100%)",
    logoColor: "#FFFFFF",
    textColor: "#CB202D",
    icon: "🍕",
    url: "https://www.zomato.com",
    rating: "4.6",
    reviews: "19,300 Ratings",
    description: "Zomato is a leading global restaurant reviews and online food delivery platform, serving food cravings across hundreds of cities in India.",
    savingTips: [
      "Join Zomato Gold to get free food deliveries, no surge fees, and dining out buy-one-get-one deals.",
      "Check out bank tie-ups (HSBC, ICICI, Axis) for active weekend cashback offers.",
      "Look for Zomato 'Promo Offers' that give flat 50% discount up to ₹120."
    ],
    faqs: [
      {
        q: "How do I apply Zomato promo codes?",
        a: "Go to your order cart, scroll down and click 'Apply Promo Code', paste the code from GrabDeals, and click apply."
      },
      {
        q: "What is Zomato Gold membership?",
        a: "Zomato Gold is a subscription program that offers free deliveries on orders above ₹199, extra restaurant discounts, and dine-in savings."
      }
    ]
  },
  Dominos: {
    name: "Domino's",
    domain: "dominos.co.in",
    color: "linear-gradient(135deg, #00649C 0%, #005482 100%)",
    logoColor: "#E31937",
    textColor: "#00649C",
    icon: "🍕",
    url: "https://www.dominos.co.in",
    rating: "4.5",
    reviews: "15,100 Ratings",
    description: "Domino's Pizza is India's most popular pizza delivery brand, serving delicious cheese pizzas, sides, and pasta under 30 minutes.",
    savingTips: [
      "Select 'Everyday Value Offers' to buy 2 medium hand-tossed pizzas at a heavily discounted price.",
      "Order on Fridays and weekends to access BOGO (Buy 1 Get 1 Free) app coupons.",
      "Collect points inside the Dominos App to redeem free pizzas and pizza voucher codes."
    ],
    faqs: [
      {
        q: "How do I apply Domino's coupons?",
        a: "In the Domino's App or website, add pizzas to your cart, click 'Apply Coupon' on the check out screen, and paste the code."
      },
      {
        q: "What is Domino's 30-minute guarantee?",
        a: "Domino's guarantees delivery within 30 minutes from placing the order. If they fail (and it's not due to force majeure), the order is compensated with a voucher."
      }
    ]
  },
  OnePlus: {
    name: "OnePlus",
    domain: "oneplus.in",
    color: "linear-gradient(135deg, #F5001C 0%, #D00018 100%)",
    logoColor: "#FFFFFF",
    textColor: "#F5001C",
    icon: "📱",
    url: "https://www.oneplus.in",
    rating: "4.7",
    reviews: "11,200 Ratings",
    description: "OnePlus is a global consumer electronics brand known for high-performance premium smartphones, earbuds, smartwatches, and Nord devices.",
    savingTips: [
      "Register with Student Beans to verify your student status and receive up to 10% off accessories.",
      "Join the OnePlus Red Cable Club for exclusive warranty upgrades and discount vouchers.",
      "Avail of bank instant discounts on ICICI and OneCard credit cards."
    ],
    faqs: [
      {
        q: "How do I use OnePlus coupon codes?",
        a: "During checkout, on the checkout summary sheet, enter your discount code in the voucher coupon section before checkout."
      },
      {
        q: "What is the Red Cable Club?",
        a: "Red Cable Club is OnePlus's free customer loyalty program that awards RCC coins, early product access, and discount tokens."
      }
    ]
  }
};

export const INITIAL_COUPONS = [
  {
    id: "swiggy-50-welcome",
    store: "Swiggy",
    discount: "50% OFF",
    title: "Flat 50% Off on Your First Order",
    description: "Get 50% discount up to ₹100 on your first food order. Valid on select restaurants.",
    code: "WELCOME50",
    isDeal: false,
    category: "food",
    expiry: "2026-08-31",
    verified: true,
    successRate: 98,
    usageCount: 1420,
    popular: true
  },
  {
    id: "amazon-10-sbi",
    store: "Amazon",
    discount: "10% OFF",
    title: "10% Instant Savings on SBI Cards",
    description: "Get 10% instant discount up to ₹1750 on purchases above ₹5000 using SBI Credit Card.",
    code: "SBIFEST10",
    isDeal: false,
    category: "electronics",
    expiry: "2026-07-25",
    verified: true,
    successRate: 94,
    usageCount: 2311
  },
  {
    id: "myntra-300-flat",
    store: "Myntra",
    discount: "₹300 OFF",
    title: "Flat ₹300 Off on First App Purchase",
    description: "Applicable on a minimum purchase of ₹1499 for new Myntra users.",
    code: "MYNNEW300",
    isDeal: false,
    category: "fashion",
    expiry: "2026-12-31",
    verified: true,
    successRate: 96,
    usageCount: 880,
    popular: true
  },
  {
    id: "hostinger-10-extra",
    store: "Hostinger",
    discount: "10% OFF",
    title: "Extra 10% Off on Web Hosting Plans",
    description: "Get an extra 10% discount on Shared, WordPress, and Cloud Hosting packages. Free SSL included.",
    code: "GRABDEALS10",
    isDeal: false,
    category: "hosting",
    expiry: "2026-10-31",
    verified: true,
    successRate: 99,
    usageCount: 520,
    popular: true
  },
  {
    id: "zomato-60-gold",
    store: "Zomato",
    discount: "60% OFF",
    title: "Up to 60% Off on Zomato Gold Orders",
    description: "Get 60% off up to ₹120 on orders above ₹199 from Zomato Gold partnered restaurants.",
    code: "GOLD60",
    isDeal: false,
    category: "food",
    expiry: "2026-07-31",
    verified: true,
    successRate: 91,
    usageCount: 1890,
    popular: true
  },
  {
    id: "flipkart-super-deal",
    store: "Flipkart",
    discount: "UP TO 80% OFF",
    title: "Electronics Clearance Sale - Mega Discounts",
    description: "Save up to 80% on smartwatches, headphones, laptops, and accessories. No coupon code required.",
    code: "",
    isDeal: true,
    category: "electronics",
    expiry: "2026-07-15",
    verified: true,
    successRate: 97,
    usageCount: 3105
  },
  {
    id: "dominos-free-pizza",
    store: "Dominos",
    discount: "FREE PIZZA",
    title: "Get 1 Free Regular Pizza on Orders over ₹400",
    description: "Order any medium pizza and get a classic regular Margherita or Garlic Bread free.",
    code: "DOMFREE",
    isDeal: false,
    category: "food",
    expiry: "2026-09-15",
    verified: true,
    successRate: 88,
    usageCount: 742,
    popular: true
  },
  {
    id: "oneplus-nord-deal",
    store: "OnePlus",
    discount: "₹2000 OFF",
    title: "Flat ₹2000 Off on OnePlus Nord Series",
    description: "Instant discount on Nord CE4 and Nord 4 using ICICI or HDFC bank credit cards.",
    code: "",
    isDeal: true,
    category: "electronics",
    expiry: "2026-08-10",
    verified: true,
    successRate: 93,
    usageCount: 430
  },
  {
    id: "myntra-sale-70",
    store: "Myntra",
    discount: "UP TO 70% OFF",
    title: "End of Reason Sale - Fashion Mega Deals",
    description: "Get 50% to 70% off on top brands including Nike, Puma, Levi's, and Roadster. Direct savings.",
    code: "",
    isDeal: true,
    category: "fashion",
    expiry: "2026-07-20",
    verified: true,
    successRate: 95,
    usageCount: 1245
  },
  {
    id: "amazon-prime-delivery",
    store: "Amazon",
    discount: "FREE TRIAL",
    title: "30-Day Free Amazon Prime Membership",
    description: "Get free fast delivery, Prime Video, Prime Music, and exclusive early access to deals.",
    code: "",
    isDeal: true,
    category: "electronics",
    expiry: "2026-12-31",
    verified: true,
    successRate: 97,
    usageCount: 1540,
    popular: true
  }
];

export function getCoupons() {
  return INITIAL_COUPONS;
}

export const DEALS_OF_THE_DAY = [
  {
    id: "dotd-1",
    store: "Amazon",
    productName: "Echo Dot (5th Gen) Smart Speaker - Deep Ocean Blue",
    image: "https://images.unsplash.com/photo-1543512214-318c7553f230?auto=format&fit=crop&w=300&q=80",
    discount: "40% OFF",
    price: "₹3,299",
    oldPrice: "₹5,499",
    link: "https://www.amazon.in",
    verified: true
  },
  {
    id: "dotd-2",
    store: "Flipkart",
    productName: "Noise ColorFit Pulse Smartwatch - Sleek Black",
    image: "https://images.unsplash.com/photo-1508685096489-7aacd43bd3b1?auto=format&fit=crop&w=300&q=80",
    discount: "70% OFF",
    price: "₹1,499",
    oldPrice: "₹4,999",
    link: "https://www.flipkart.com",
    verified: true
  },
  {
    id: "dotd-3",
    store: "Myntra",
    productName: "Puma Classic Unisex Suede Sneakers",
    image: "https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=300&q=80",
    discount: "55% OFF",
    price: "₹1,799",
    oldPrice: "₹3,999",
    link: "https://www.myntra.com",
    verified: true
  },
  {
    id: "dotd-4",
    store: "OnePlus",
    productName: "OnePlus Nord Buds 2r - Triple Titanium",
    image: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=300&q=80",
    discount: "20% OFF",
    price: "₹1,999",
    oldPrice: "₹2,499",
    link: "https://www.oneplus.in",
    verified: true
  }
];

export const COLLECTIONS = [
  {
    id: "col-1",
    title: "Food Delivery Loot",
    description: "Save big on your cravings! Flat discounts & free delivery offers on Swiggy and Zomato.",
    image: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=400&q=80",
    count: "15 Active Coupons",
    tag: "Food & Dining",
    filterStore: null,
    filterCat: "food"
  },
  {
    id: "col-2",
    title: "Fashion Wardrobe Sale",
    description: "Upgrade your style quotient! Up to 70% Off on top fashion brands on Myntra.",
    image: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=400&q=80",
    count: "22 Deals Live",
    tag: "Fashion & Apparel",
    filterStore: "Myntra",
    filterCat: "fashion"
  },
  {
    id: "col-3",
    title: "Web Setup Essentials",
    description: "Launch your website today! Premium web hosting and free domains coupon codes.",
    image: "https://images.unsplash.com/photo-1600132806370-bf17e65e942f?auto=format&fit=crop&w=400&q=80",
    count: "8 Verified Codes",
    tag: "Hosting & Domains",
    filterStore: "Hostinger",
    filterCat: "hosting"
  },
  {
    id: "col-4",
    title: "Electronics & Smart Tech",
    description: "Smart savings for smart living! Hot deals on mobiles, tech, & home accessories.",
    image: "https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=400&q=80",
    count: "18 Hot Deals",
    tag: "Electronics & Mobiles",
    filterStore: null,
    filterCat: "electronics"
  }
];
