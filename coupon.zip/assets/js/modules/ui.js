// UI Renderer and Interaction Logic
import { STORES, CATEGORIES } from "./coupons.js";
import { isBookmarked, toggleBookmark, addSubmission, saveFeedback, getFeedbackFor } from "./storage.js";
import { triggerConfetti } from "./confetti.js";

// Render the Coupon Grid Cards
export function renderCoupons(coupons, container, onCouponAction) {
  container.innerHTML = "";
  
  if (coupons.length === 0) {
    container.innerHTML = `
      <div class="empty-state">
        <div class="empty-icon">🔍</div>
        <h3>No coupons found</h3>
        <p>Try searching for another store or category, or submit your own coupon!</p>
      </div>
    `;
    return;
  }

  coupons.forEach((coupon) => {
    const storeMeta = STORES[coupon.store] || {
      name: coupon.store,
      color: "linear-gradient(135deg, #4b5563 0%, #1f2937 100%)",
      textColor: "#ffffff",
      icon: "🏷️"
    };

    const card = document.createElement("div");
    card.className = "coupon-card";
    card.setAttribute("data-id", coupon.id);

    const isFav = isBookmarked(coupon.id);
    const starIcon = isFav ? '<i class="fa-solid fa-star"></i>' : '<i class="fa-regular fa-star"></i>';
    const favClass = isFav ? "bookmarked" : "";
    const logoUrl = storeMeta.domain ? `https://logos.hunter.io/${storeMeta.domain}` : "";

    card.innerHTML = `
      <div class="coupon-header">
        <a href="store.html?store=${coupon.store}" class="store-badge" style="background: ${storeMeta.color}; text-decoration: none;">
          <div class="store-badge-logo-container">
            ${logoUrl 
              ? `<img src="${logoUrl}" alt="${coupon.store}" class="store-badge-logo-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">` 
              : ""
            }
            <span class="store-icon" style="${logoUrl ? "display: none;" : ""}">${storeMeta.icon}</span>
          </div>
          <span class="store-name">${coupon.store}</span>
        </a>
        <button class="bookmark-btn ${favClass}" title="Bookmark Offer">${starIcon}</button>
      </div>
      
      <div class="coupon-body">
        <div class="discount-pill">${coupon.discount}</div>
        <h3 class="coupon-title">${coupon.title}</h3>
        <p class="coupon-desc">${coupon.description}</p>
        
        <div class="coupon-meta">
          <span class="meta-item verified-badge">
            <span class="verified-icon">✓</span> Verified
          </span>
          <span class="meta-item usage-count">
            🔥 ${coupon.usageCount.toLocaleString()} used today
          </span>
          <span class="meta-item success-rate">
            👍 ${coupon.successRate}% Success
          </span>
        </div>
      </div>
      
      <div class="coupon-footer">
        <div class="expiry-date">Expires: ${formatDate(coupon.expiry)}</div>
        <button class="action-btn ${coupon.isDeal ? 'deal-btn' : 'code-btn'}">
          ${coupon.isDeal 
            ? '<span>Get Deal</span><span class="btn-arrow">→</span>' 
            : `<span>Show Code</span><span class="code-stub">${coupon.code.substring(0, 3)}...</span>`
          }
        </button>
      </div>
    `;

    // Wire up event listeners
    card.querySelector(".bookmark-btn").addEventListener("click", (e) => {
      e.stopPropagation();
      const updatedBookmarks = toggleBookmark(coupon.id);
      const isNowFav = updatedBookmarks.includes(coupon.id);
      
      // Update UI button state
      const btn = e.currentTarget;
      btn.innerHTML = isNowFav ? "★" : "☆";
      btn.classList.toggle("bookmarked", isNowFav);
      
      // Trigger header bookmark count update
      document.dispatchEvent(new CustomEvent("bookmarks-changed"));
    });

    card.querySelector(".action-btn").addEventListener("click", () => {
      onCouponAction(coupon);
    });

    container.appendChild(card);
  });
}

// Render Stores Carousel / Grid
export function renderStoreSelectors(container, onSelectStore, activeStore) {
  container.innerHTML = "";
  
  // Add an "All Stores" option first
  const allBtn = document.createElement("button");
  allBtn.className = `store-selector-card ${!activeStore ? "active" : ""}`;
  allBtn.innerHTML = `
    <div class="store-sel-logo" style="background: linear-gradient(135deg, #111827 0%, #1f2937 100%)">🏠</div>
    <span>All Stores</span>
  `;
  allBtn.addEventListener("click", () => onSelectStore(null));
  container.appendChild(allBtn);

  Object.keys(STORES).forEach((storeKey) => {
    const store = STORES[storeKey];
    const btn = document.createElement("button");
    btn.className = `store-selector-card ${activeStore === storeKey ? "active" : ""}`;
    
    const logoUrl = store.domain ? `https://logos.hunter.io/${store.domain}` : "";

    btn.innerHTML = `
      <div class="store-sel-logo" style="background: ${store.color}">
        ${logoUrl 
          ? `<img src="${logoUrl}" alt="${store.name}" class="store-logo-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">` 
          : ""
        }
        <span class="store-logo-fallback" style="${logoUrl ? "display: none;" : ""}">${store.icon}</span>
      </div>
      <span>${store.name}</span>
    `;
    btn.addEventListener("click", () => {
      window.location.href = `store.html?store=${storeKey}`;
    });
    container.appendChild(btn);
  });
}

// Display Interstitial / Copy Coupon Modal
export function openCopyModal(coupon) {
  const storeMeta = STORES[coupon.store] || {
    color: "#1f2937",
    icon: "🏷️",
    url: "#"
  };

  const overlay = document.createElement("div");
  overlay.className = "modal-overlay";
  
  const currentFeedback = getFeedbackFor(coupon.id);
  const feedbackSectionHTML = currentFeedback
    ? `<p class="feedback-done">Thank you for your feedback! (Status: ${currentFeedback === "upvote" ? "Working 👍" : "Expired 👎"})</p>`
    : `
      <p>Did this coupon code work?</p>
      <div class="feedback-btns">
        <button class="feed-btn yes-btn" id="feed-yes">👍 Yes, it worked</button>
        <button class="feed-btn no-btn" id="feed-no">👎 No, expired/broken</button>
      </div>
    `;

  overlay.innerHTML = `
    <div class="modal-card">
      <button class="modal-close-btn"><i class="fa-solid fa-xmark"></i></button>
      
      <div class="modal-header">
        <div class="modal-store-badge" style="background: ${storeMeta.color}">
          ${storeMeta.icon}
        </div>
        <h2>${coupon.store}</h2>
      </div>

      <div class="modal-body">
        <div class="modal-discount">${coupon.discount}</div>
        <h3 class="modal-title">${coupon.title}</h3>
        <p class="modal-desc">${coupon.description}</p>

        ${coupon.isDeal 
          ? `
            <div class="deal-activated-box">
              <span class="check-circle">✓</span>
              <span>Deal Activated! No promo code is required at checkout.</span>
            </div>
            <a href="${storeMeta.url}" target="_blank" class="modal-visit-btn">
              Go to ${coupon.store} Store &rarr;
            </a>
          `
          : `
            <div class="copy-box-container">
              <div class="code-display" id="modal-code-text">${coupon.code}</div>
              <button class="copy-action-btn" id="modal-copy-btn">Copy Code</button>
            </div>
            <div class="copy-success-message" id="copy-success-msg">Code Copied to Clipboard! 🚀</div>
            
            <a href="${storeMeta.url}" target="_blank" class="modal-visit-btn">
              Go to ${coupon.store} & Paste Code &rarr;
            </a>
          `
        }

        <div class="modal-steps">
          <h4>How to use this offer:</h4>
          <ol>
            ${coupon.isDeal 
              ? `
                <li>Click the "Go to Store" button above.</li>
                <li>The discount is already activated and will be pre-applied.</li>
                <li>Add qualified items to your cart and check out.</li>
              `
              : `
                <li>Click the "Copy Code" button above.</li>
                <li>Click "Go to Store" to visit ${coupon.store} in a new tab.</li>
                <li>Paste the copied code <strong>${coupon.code}</strong> into the promo code box at checkout.</li>
              `
            }
          </ol>
        </div>

        <div class="modal-feedback" id="feedback-container">
          ${feedbackSectionHTML}
        </div>
      </div>
    </div>
  `;

  document.body.appendChild(overlay);
  // Add dynamic animations
  setTimeout(() => overlay.classList.add("active"), 10);

  // Close triggers
  const close = () => {
    overlay.classList.remove("active");
    setTimeout(() => overlay.remove(), 300);
  };
  overlay.querySelector(".modal-close-btn").addEventListener("click", close);
  overlay.addEventListener("click", (e) => {
    if (e.target === overlay) close();
  });

  // Copy Action
  if (!coupon.isDeal) {
    const copyBtn = overlay.querySelector("#modal-copy-btn");
    copyBtn.addEventListener("click", () => {
      navigator.clipboard.writeText(coupon.code).then(() => {
        // Success animation
        copyBtn.innerText = "Copied!";
        copyBtn.classList.add("success");
        overlay.querySelector("#copy-success-msg").classList.add("visible");
        
        triggerConfetti();
        
        setTimeout(() => {
          copyBtn.innerText = "Copy Code";
          copyBtn.classList.remove("success");
        }, 3000);
      });
    });
  }

  // Feedback upvote/downvote
  if (!currentFeedback) {
    const yesBtn = overlay.querySelector("#feed-yes");
    const noBtn = overlay.querySelector("#feed-no");
    const fbContainer = overlay.querySelector("#feedback-container");

    const submitFeedback = (status) => {
      saveFeedback(coupon.id, status);
      fbContainer.innerHTML = `<p class="feedback-done">Thank you for your feedback! (Status: ${status === "upvote" ? "Working 👍" : "Expired 👎"})</p>`;
    };

    if (yesBtn) yesBtn.addEventListener("click", () => submitFeedback("upvote"));
    if (noBtn) noBtn.addEventListener("click", () => submitFeedback("downvote"));
  }
}

// Savings Calculator Widget Setup
export function setupSavingsCalculator() {
  const foodSlider = document.getElementById("spend-food");
  const fashionSlider = document.getElementById("spend-fashion");
  const electroSlider = document.getElementById("spend-electronics");
  const travelSlider = document.getElementById("spend-travel");

  const foodVal = document.getElementById("val-food");
  const fashionVal = document.getElementById("val-fashion");
  const electroVal = document.getElementById("val-electronics");
  const travelVal = document.getElementById("val-travel");

  const annualSavingsEl = document.getElementById("calc-savings-amount");
  const monthlySavingsEl = document.getElementById("calc-monthly-savings");

  function calculate() {
    const food = parseInt(foodSlider.value);
    const fashion = parseInt(fashionSlider.value);
    const electro = parseInt(electroSlider.value);
    const travel = parseInt(travelSlider.value);

    // Update Slider Value Texts
    foodVal.innerText = `₹${food.toLocaleString()}`;
    fashionVal.innerText = `₹${fashion.toLocaleString()}`;
    electroVal.innerText = `₹${electro.toLocaleString()}`;
    travelVal.innerText = `₹${travel.toLocaleString()}`;

    // Savings rates: Food 15%, Fashion 20%, Electronics 8%, Travel 12%
    const monthlyFoodSavings = food * 0.15;
    const monthlyFashionSavings = fashion * 0.20;
    const annualElectroSavings = electro * 0.08;
    const monthlyTravelSavings = travel * 0.12;

    const monthlyTotal = monthlyFoodSavings + monthlyFashionSavings + (annualElectroSavings / 12) + monthlyTravelSavings;
    const annualTotal = monthlyTotal * 12;

    // Animate target numbers
    animateCounter(annualSavingsEl, Math.round(annualTotal));
    animateCounter(monthlySavingsEl, Math.round(monthlyTotal));
  }

  [foodSlider, fashionSlider, electroSlider, travelSlider].forEach((slider) => {
    slider.addEventListener("input", calculate);
  });

  calculate(); // Run initial calculation
}

// Simple Counter Ticker animation
function animateCounter(element, target) {
  const current = parseInt(element.innerText.replace(/[^0-9]/g, "")) || 0;
  const duration = 400; // ms
  const start = performance.now();

  function update(timestamp) {
    const elapsed = timestamp - start;
    const progress = Math.min(elapsed / duration, 1);
    
    // Ease-out formula
    const ease = 1 - Math.pow(1 - progress, 3);
    const value = Math.round(current + (target - current) * ease);

    element.innerText = `₹${value.toLocaleString()}`;

    if (progress < 1) {
      requestAnimationFrame(update);
    }
  }

  requestAnimationFrame(update);
}

// Setup Header Search Box Autosuggest
export function setupSearchAutosuggest(onSelectStore, onSelectCategory) {
  const searchInput = document.getElementById("search-input");
  const suggestBox = document.getElementById("search-suggestions");

  if (!searchInput || !suggestBox) return;

  searchInput.addEventListener("input", (e) => {
    const query = e.target.value.trim().toLowerCase();
    
    if (query.length < 2) {
      suggestBox.classList.remove("active");
      return;
    }

    // Filter Stores and Categories
    const matchedStores = Object.keys(STORES).filter((storeKey) => 
      storeKey.toLowerCase().includes(query)
    );

    const matchedCats = CATEGORIES.filter((cat) => 
      cat.id !== "all" && cat.name.toLowerCase().includes(query)
    );

    if (matchedStores.length === 0 && matchedCats.length === 0) {
      suggestBox.innerHTML = `<div class="suggest-item empty">No store or category found</div>`;
      suggestBox.classList.add("active");
      return;
    }

    suggestBox.innerHTML = "";
    
    if (matchedStores.length > 0) {
      const title = document.createElement("div");
      title.className = "suggest-group-title";
      title.innerText = "Stores";
      suggestBox.appendChild(title);

      matchedStores.forEach((storeKey) => {
        const store = STORES[storeKey];
        const item = document.createElement("div");
        item.className = "suggest-item";
        item.innerHTML = `<span>${store.icon}</span> <strong>${store.name}</strong>`;
        item.addEventListener("click", () => {
          onSelectStore(storeKey);
          searchInput.value = store.name;
          suggestBox.classList.remove("active");
        });
        suggestBox.appendChild(item);
      });
    }

    if (matchedCats.length > 0) {
      const title = document.createElement("div");
      title.className = "suggest-group-title";
      title.innerText = "Categories";
      suggestBox.appendChild(title);

      matchedCats.forEach((cat) => {
        const item = document.createElement("div");
        item.className = "suggest-item";
        item.innerHTML = `<span>${cat.icon}</span> <strong>${cat.name}</strong>`;
        item.addEventListener("click", () => {
          onSelectCategory(cat.id);
          searchInput.value = cat.name;
          suggestBox.classList.remove("active");
        });
        suggestBox.appendChild(item);
      });
    }

    suggestBox.classList.add("active");
  });

  // Close suggestion box on outer clicks
  document.addEventListener("click", (e) => {
    if (!searchInput.contains(e.target) && !suggestBox.contains(e.target)) {
      suggestBox.classList.remove("active");
    }
  });
}

// Setup Slide Drawer for Submitting New Coupon
export function setupSubmitDrawer(onNewSubmission) {
  const drawer = document.getElementById("submit-drawer");
  const openBtn = document.getElementById("header-submit-btn");
  const closeBtn = document.getElementById("drawer-close-btn");
  const form = document.getElementById("submit-coupon-form");

  if (!drawer || !openBtn || !closeBtn || !form) return;

  // Open Drawer
  openBtn.addEventListener("click", () => {
    drawer.classList.add("active");
  });

  // Close Drawer
  const closeDrawer = () => {
    drawer.classList.remove("active");
  };
  closeBtn.addEventListener("click", closeDrawer);
  
  // Submit Form
  form.addEventListener("submit", (e) => {
    e.preventDefault();

    const store = document.getElementById("form-store").value;
    const discount = document.getElementById("form-discount").value;
    const title = document.getElementById("form-title").value;
    const description = document.getElementById("form-desc").value;
    const code = document.getElementById("form-code").value.trim().toUpperCase();
    const category = document.getElementById("form-category").value;
    const expiry = document.getElementById("form-expiry").value;

    const isDeal = !code;

    const newCoupon = {
      id: `custom-${Date.now()}`,
      store: store,
      discount: discount,
      title: title,
      description: description,
      code: code,
      isDeal: isDeal,
      category: category,
      expiry: expiry || new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0], // default 30 days
      verified: false,
      successRate: 100,
      usageCount: 0
    };

    addSubmission(newCoupon);
    
    // Alert Notification
    showNotification(`Coupon submitted successfully for ${store}! 🎉`);

    form.reset();
    closeDrawer();

    if (onNewSubmission) {
      onNewSubmission(newCoupon);
    }
  });
}

// Helper: Custom Toast Notification
export function showNotification(message) {
  const toast = document.createElement("div");
  toast.className = "toast-notification";
  toast.innerText = message;
  document.body.appendChild(toast);

  setTimeout(() => toast.classList.add("visible"), 10);
  setTimeout(() => {
    toast.classList.remove("visible");
    setTimeout(() => toast.remove(), 300);
  }, 4000);
}

// Helper: Date Formatter
function formatDate(dateString) {
  const options = { year: 'numeric', month: 'short', day: 'numeric' };
  const d = new Date(dateString);
  if (isNaN(d.getTime())) return dateString; // fallback
  return d.toLocaleDateString('en-IN', options);
}

// Render Deals Of The Day Section
export function renderDealsOfTheDay(deals, container) {
  if (!container) return;
  container.innerHTML = "";

  deals.forEach((deal) => {
    const storeMeta = STORES[deal.store] || {
      name: deal.store,
      icon: "🏷️"
    };

    const logoUrl = storeMeta.domain ? `https://logos.hunter.io/${storeMeta.domain}` : "";

    const card = document.createElement("div");
    card.className = "deal-of-the-day-card";
    card.innerHTML = `
      <div class="deal-image-wrapper">
        <div class="deal-discount-badge">${deal.discount}</div>
        <div class="deal-store-badge">
          ${logoUrl 
            ? `<img src="${logoUrl}" alt="${deal.store}" class="deal-store-logo-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">` 
            : ""
          }
          <span class="store-icon" style="${logoUrl ? 'display: none;' : ''}">${storeMeta.icon}</span>
        </div>
        <img src="${deal.image}" alt="${deal.productName}" class="deal-img">
      </div>
      <div class="deal-details">
        <h4 class="deal-product-name" title="${deal.productName}">${deal.productName}</h4>
        <div>
          <div class="deal-price-row">
            <span class="deal-current-price">${deal.price}</span>
            <span class="deal-old-price">${deal.oldPrice}</span>
          </div>
          <a href="${deal.link}" target="_blank" class="deal-card-cta">Get Deal</a>
        </div>
      </div>
    `;
    container.appendChild(card);
  });
}

// Render Collections Section
export function renderCollections(collections, container, onSelectCollection) {
  if (!container) return;
  container.innerHTML = "";

  collections.forEach((col) => {
    const card = document.createElement("div");
    card.className = "collection-card";
    card.innerHTML = `
      <img src="${col.image}" alt="${col.title}" class="collection-bg-img">
      <div class="collection-overlay"></div>
      <div class="collection-content">
        <span class="collection-tag">${col.tag}</span>
        <h4 class="collection-title">${col.title}</h4>
        <p class="collection-desc">${col.description}</p>
        <span class="collection-count">${col.count}</span>
      </div>
    `;
    card.addEventListener("click", () => {
      onSelectCollection(col);
    });
    container.appendChild(card);
  });
}

// Check logged in user profile and updates header actions
export function setupHeaderAuthProfile() {
  const user = JSON.parse(localStorage.getItem("user_profile"));
  const headerActions = document.querySelector(".header-actions");
  if (!headerActions) return;

  // Find existing login button or profile badge
  const existingLogin = document.getElementById("user-profile-btn");
  if (existingLogin) existingLogin.remove();

  if (user) {
    // Create profile badge link
    const badge = document.createElement("a");
    badge.href = "#";
    badge.className = "user-profile-badge";
    badge.id = "user-profile-btn";
    
    // Get initials
    const initials = user.name ? user.name.split(" ").map(n => n[0]).join("").toUpperCase().slice(0, 2) : "U";

    badge.innerHTML = `
      <div class="user-avatar-circle">${initials}</div>
      <span>Hello, ${user.name.split(" ")[0]}</span>
    `;

    // Click to logout
    badge.addEventListener("click", (e) => {
      e.preventDefault();
      if (confirm("Would you like to logout from GrabDeals?")) {
        localStorage.removeItem("user_profile");
        showNotification("Logged out successfully! See you soon. 👋");
        setupHeaderAuthProfile(); // refresh header
      }
    });

    headerActions.insertBefore(badge, headerActions.firstChild);
  } else {
    // Render default login link
    const loginLink = document.createElement("a");
    loginLink.href = "login.html";
    loginLink.className = "login-btn-header";
    loginLink.id = "user-profile-btn";
    loginLink.innerHTML = '<i class="fa-solid fa-circle-user"></i> Login';

    headerActions.insertBefore(loginLink, headerActions.firstChild);
  }
}

// Render Popular Offers Slider Cards
export function renderPopularOffers(coupons, container, onSelectOffer) {
  if (!container) return;
  container.innerHTML = "";

  const STORE_BANNERS = {
    Swiggy: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=400&q=80",
    Zomato: "https://images.unsplash.com/photo-1565299624946-b28f40a0ae38?auto=format&fit=crop&w=400&q=80",
    Dominos: "https://images.unsplash.com/photo-1513104890138-7c749659a591?auto=format&fit=crop&w=400&q=80",
    Myntra: "https://images.unsplash.com/photo-1490481651871-ab68de25d43d?auto=format&fit=crop&w=400&q=80",
    Hostinger: "https://images.unsplash.com/photo-1600132806370-bf17e65e942f?auto=format&fit=crop&w=400&q=80",
    Amazon: "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=400&q=80",
    Flipkart: "https://images.unsplash.com/photo-1526738549149-8e07eca6c147?auto=format&fit=crop&w=400&q=80",
    OnePlus: "https://images.unsplash.com/photo-1590658268037-6bf12165a8df?auto=format&fit=crop&w=400&q=80"
  };

  coupons.forEach((coupon) => {
    const storeMeta = STORES[coupon.store] || {
      name: coupon.store,
      color: "linear-gradient(135deg, #4b5563 0%, #1f2937 100%)",
      icon: "🏷️"
    };

    const bannerImg = STORE_BANNERS[coupon.store] || "https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=400&q=80";
    const logoUrl = storeMeta.domain ? `https://logos.hunter.io/${storeMeta.domain}` : "";
    const ctaText = coupon.isDeal ? "Get Deal" : "Get Code";

    const card = document.createElement("div");
    card.className = "popular-slider-card";
    card.innerHTML = `
      <div class="popular-card-image-wrapper">
        <img src="${bannerImg}" alt="${coupon.store} Promo" class="popular-card-banner-img">
        <div class="popular-card-overlay"></div>
        <div class="popular-card-discount-badge">${coupon.discount}</div>
        <div class="popular-card-store-badge">
          ${logoUrl 
            ? `<img src="${logoUrl}" alt="${coupon.store}" class="popular-card-store-logo-img" onerror="this.style.display='none'; this.nextElementSibling.style.display='block';">` 
            : ""
          }
          <span class="store-icon" style="${logoUrl ? 'display: none;' : ''}; font-size: 1rem;">${storeMeta.icon}</span>
        </div>
      </div>
      <div class="popular-card-details">
        <h4 class="popular-card-title" title="${coupon.title}">${coupon.title}</h4>
        <div class="popular-card-stats">
          <span>🔥 ${coupon.usageCount || 450} used today</span>
          <span style="color: var(--success-color);">✔ Verified</span>
        </div>
        <button class="deal-card-cta" style="margin-top: 5px;">${ctaText} &rarr;</button>
      </div>
    `;
    
    // Bind click trigger to copy-coupon modal
    card.querySelector(".deal-card-cta").addEventListener("click", () => {
      onSelectOffer(coupon);
    });
    
    container.appendChild(card);
  });
}
