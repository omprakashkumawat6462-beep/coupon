// LocalStorage Manager for Bookmarks and Submissions

const BOOKMARKS_KEY = "grabdeals_bookmarks";
const SUBMISSIONS_KEY = "grabdeals_submissions";
const FEEDBACKS_KEY = "grabdeals_feedbacks";

export function getBookmarks() {
  const bookmarks = localStorage.getItem(BOOKMARKS_KEY);
  return bookmarks ? JSON.parse(bookmarks) : [];
}

export function saveBookmarks(bookmarks) {
  localStorage.setItem(BOOKMARKS_KEY, JSON.stringify(bookmarks));
}

export function toggleBookmark(couponId) {
  const bookmarks = getBookmarks();
  const index = bookmarks.indexOf(couponId);
  if (index === -1) {
    bookmarks.push(couponId);
  } else {
    bookmarks.splice(index, 1);
  }
  saveBookmarks(bookmarks);
  return bookmarks;
}

export function isBookmarked(couponId) {
  return getBookmarks().includes(couponId);
}

export function getSubmissions() {
  const submissions = localStorage.getItem(SUBMISSIONS_KEY);
  return submissions ? JSON.parse(submissions) : [];
}

export function addSubmission(coupon) {
  const submissions = getSubmissions();
  submissions.unshift(coupon); // Add new coupon to the top of submissions
  localStorage.setItem(SUBMISSIONS_KEY, JSON.stringify(submissions));
  return submissions;
}

export function saveFeedback(couponId, status) {
  // status is either 'upvote' or 'downvote'
  const feedbacks = getFeedbacks();
  feedbacks[couponId] = status;
  localStorage.setItem(FEEDBACKS_KEY, JSON.stringify(feedbacks));
}

export function getFeedbacks() {
  const feedbacks = localStorage.getItem(FEEDBACKS_KEY);
  return feedbacks ? JSON.parse(feedbacks) : {};
}

export function getFeedbackFor(couponId) {
  return getFeedbacks()[couponId] || null;
}
