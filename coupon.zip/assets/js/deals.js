// GrabDeals Deals Landing Page Controller
import { DEALS_OF_THE_DAY, STORES } from "./modules/coupons.js";
import { getBookmarks } from "./modules/storage.js";
import { 
  renderDealsOfTheDay, 
  setupSearchAutosuggest, 
  setupSubmitDrawer,
  showNotification,
  setupHeaderAuthProfile
} from "./modules/ui.js";

// DOM Cache
const dealsGrid = document.getElementById("deals-grid-container");
const filterStore = document.getElementById("filter-store");
const filterCategory = document.getElementById("filter-category");
const resultsCount = document.getElementById("deals-results-count");
const bookmarkBadge = document.getElementById("bookmark-badge");
const themeToggle = document.getElementById("theme-toggle-btn");
const themeIcon = document.getElementById("theme-icon");

// State
let selectedStore = "all";
let selectedCategory = "all";

document.addEventListener("DOMContentLoaded", () => {
  initDealsPage();
});

function initDealsPage() {
  // 1. Setup Theme
  setupTheme();

  // 2. Initial render of deals catalog grid
  updateDealsGrid();

  // 3. Setup Deals Countdown timer
  setupDealsTimer();

  // 4. Setup Input change listeners for filters
  filterStore.addEventListener("change", (e) => {
    selectedStore = e.target.value;
    updateDealsGrid();
  });

  filterCategory.addEventListener("change", (e) => {
    selectedCategory = e.target.value;
    updateDealsGrid();
  });

  // 5. Setup Submit Coupon Drawer
  setupSubmitDrawer(() => {
    showNotification("Coupon submitted successfully for moderation! 🚀");
  });

  // 6. Setup Search Autosuggestion
  setupSearchAutosuggest(
    (store) => { window.location.href = `store.html?store=${store}`; },
    (cat) => { window.location.href = `category.html?cat=${cat}`; }
  );

  // 7. Update Bookmarks Badge
  updateBookmarksBadge();
  document.addEventListener("bookmarks-changed", updateBookmarksBadge);

  // 8. Update User Auth profile details in header
  setupHeaderAuthProfile();
}

function updateDealsGrid() {
  // Filter the static deals list based on store and category inputs
  let filtered = DEALS_OF_THE_DAY;

  if (selectedStore !== "all") {
    filtered = filtered.filter(
      d => d.store.toLowerCase() === selectedStore.toLowerCase()
    );
  }

  if (selectedCategory !== "all") {
    filtered = filtered.filter(d => {
      // Map store to its category or resolve product details
      if (selectedCategory === "electronics") {
        return d.productName.toLowerCase().includes("echo") || 
               d.productName.toLowerCase().includes("buds") || 
               d.productName.toLowerCase().includes("pulse") ||
               d.productName.toLowerCase().includes("oneplus");
      }
      if (selectedCategory === "fashion") {
        return d.productName.toLowerCase().includes("sneakers") || 
               d.productName.toLowerCase().includes("puma") ||
               d.store.toLowerCase() === "myntra";
      }
      return true;
    });
  }

  resultsCount.innerText = `Showing ${filtered.length} Hot Deals`;

  if (filtered.length === 0) {
    dealsGrid.innerHTML = `
      <div class="no-results-card" style="grid-column: 1 / -1; width: 100%;">
        <p style="font-size: 1.1rem; font-weight: 600;">No daily product deals match your filters!</p>
        <p style="color: var(--text-muted); font-size: 0.85rem; margin-top: 5px;">Try changing your store or category selection.</p>
      </div>
    `;
    return;
  }

  renderDealsOfTheDay(filtered, dealsGrid);
}

// Deals Countdown Timer
function setupDealsTimer() {
  const timerElement = document.getElementById("deals-timer");
  if (!timerElement) return;

  function updateTimer() {
    const now = new Date();
    const midnight = new Date(now.getFullYear(), now.getMonth(), now.getDate() + 1, 0, 0, 0);
    const diff = midnight - now;

    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor((diff % (1000 * 60 * 60)) / (1000 * 60));
    const seconds = Math.floor((diff % (1000 * 60)) / 1000);

    const pad = (num) => String(num).padStart(2, "0");
    timerElement.innerText = `${pad(hours)}:${pad(minutes)}:${pad(seconds)}`;
  }

  setInterval(updateTimer, 1000);
  updateTimer();
}

function setupTheme() {
  const currentTheme = localStorage.getItem("theme") || "dark";
  document.documentElement.setAttribute("data-theme", currentTheme);
  updateThemeIcon(currentTheme);

  themeToggle.addEventListener("click", () => {
    const theme = document.documentElement.getAttribute("data-theme") === "dark" ? "light" : "dark";
    document.documentElement.setAttribute("data-theme", theme);
    localStorage.setItem("theme", theme);
    updateThemeIcon(theme);
  });
}

function updateThemeIcon(theme) {
  themeIcon.innerHTML = theme === "dark" ? '<i class="fa-solid fa-sun"></i>' : '<i class="fa-solid fa-moon"></i>';
}

function updateBookmarksBadge() {
  const bookmarks = getBookmarks();
  bookmarkBadge.innerText = bookmarks.length;
}


